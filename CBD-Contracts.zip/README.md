# Sample Hardhat Project

This project demonstrates a basic Hardhat use case. It comes with a sample contract, a test for that contract, and a script that deploys that contract.

Try running some of the following tasks:

goerli-CBD:
https://goerli.etherscan.io/address/0x6e8eCf88F39E08e06764Ff26d67c1ed99f8ea1CE

goerli-purchase:
https://goerli.etherscan.io/address/0x2F49676E78f0480889A87603e971C13C7058C11e

```shell
npx hardhat help
npx hardhat test
REPORT_GAS=true npx hardhat test
npx hardhat node
npx hardhat run scripts/deploy.ts
```
"# CBD-Contracts" 
"# CBD-Contracts" 
"# CBD-Contracts" 
"# CBD-Contracts" 
